<?php
/**
 * The Template for displaying all single products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     1.6.4
 */

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

get_header('shop'); ?>
<section class="section breadcrumb-section">
	<div class="container">
		<div class="inner">
			<?php
			/**
			 * woocommerce_before_main_content hook.
			 *
			 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
			 * @hooked woocommerce_breadcrumb - 20
			 */
			do_action('woocommerce_before_main_content');
			?>
		</div>
	</div>
</section>


<?php while (have_posts()): ?>
	<?php the_post(); ?>

	<?php
	//wc_get_template_part( 'content', 'single-product' );

	global $product;

	// Get product details
	$product_id = $product->get_id();
	$product_images = $product->get_gallery_image_ids();
	$regular_price = $product->get_regular_price();
	$sale_price = $product->get_sale_price();
	$is_on_sale = $product->is_on_sale();
	$short_description = $product->get_short_description();
	$full_description = $product->get_description();
	$average_rating = $product->get_average_rating();
	$ingredients = get_post_meta($product->get_id(), 'ingredients', true);

	?>
    <section class="section product-inner-section">
        <div class="container">
            <div class="inner">
                <div class="left">
                    <div class="image">
                        <img src="https://naviforcewatches.pk/wp-content/uploads/2022/10/b1-768x384.jpg" alt="">
                    </div>
                </div>
                <div class="right">
                    <h2><?php the_title(); ?>
                    </h2>
                    <h3 class="price">
					<?php if ($is_on_sale): ?>
								<span class="original"><?php echo wc_price($regular_price); ?></span>
								<span class="new"><?php echo wc_price($sale_price); ?></span>
							<?php else: ?>
								<span class="new"><?php echo wc_price($regular_price); ?></span>
							<?php endif; ?>
                    </h3>
                    <p class="info">
					<?php echo wpautop($short_description); ?>
                    </p>
                    <h4 class="code">SKU: #e0395</h4>
                    <div class="stock">
                        <span class="in-stock">In Stock</span>
                        <span class="out-stock">Out Stock</span>
                    </div>
					<?php do_action('woocommerce_before_add_to_cart_button'); ?>
							<form class="cart" method="post" enctype='multipart/form-data'>
								<div class="incrementor">
									<button type="button" class="minus">-</button>
									<input type="number" id="quantity_input" class="input-text qty text value"
										min="<?php echo esc_attr($product->get_min_purchase_quantity()); ?>"
										max="<?php echo esc_attr($product->get_max_purchase_quantity()); ?>" name="quantity"
										value="<?php echo esc_attr($product->get_min_purchase_quantity()); ?>" title="Qty"
										size="4" pattern="[0-9]*" inputmode="numeric">
									<button type="button" class="plus">+</button>

								</div>
								<div class="cart-button">
									<input type="hidden" name="add-to-cart"
										value="<?php echo absint($product->get_id()); ?>">
									<button type="submit" name="add-to-cart"
										value="<?php echo esc_attr($product->get_id()); ?>"
										class="single_add_to_cart_button main-button"><?php echo esc_html($product->single_add_to_cart_text()); ?></button>
										<?php do_action('woocommerce_after_add_to_cart_button'); ?>
								</div>
								<div class="like">
				 <?php
				 echo do_shortcode("[ti_wishlists_addtowishlist loop=yes]");
				?>
								</div>
							</form>

                    <!-- <div class="cart-number">
                        <div class="display">
                            <span class="operator">-</span>
                            <span class="operand"><input type="number"></span>
                            <span class="operator">+</span>
                        </div>
                        <div class="button">
                            <button class="main-button cart-button">
                                <span class="icon"><i class="fa-solid fa-cart-shopping"></i></span>
                                <span class="text">Add To Cart</span>
                            </button>
                            <div class="like-button">
                                <i class="fa-regular fa-heart"></i>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div>
        </div>
    </section>
    <section class="section product-tab-section">
        <div class="container">
            <div class="inner">
                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                      <button class="nav-link active" id="pills-product-images-tab" data-bs-toggle="pill" data-bs-target="#pills-product-images"
                        type="button" role="tab" aria-controls="pills-snacks" aria-selected="true">Product Images</button>
                    </li>
                    <li class="nav-item" role="presentation">
                      <button class="nav-link" id="pills-product-description-tab" data-bs-toggle="pill"
                        data-bs-target="#pills-product-description" type="button" role="tab" aria-controls="pills-product-description"
                        aria-selected="false">Product Description</button>
                    </li>
                    <li class="nav-item" role="presentation">
                      <button class="nav-link" id="pills-shipping-policy-tab" data-bs-toggle="pill" data-bs-target="#pills-shipping-policy"
                        type="button" role="tab" aria-controls="pills-shipping-policy" aria-selected="false">Shipping Policy</button>
                    </li>
                  </ul>
                  <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-product-images" role="tabpanel" aria-labelledby="pills-product-images-tab"
                      tabindex="0">
                      <img src="https://www.naviforce-watch.com/wp-content/uploads/2023/04/5-282.jpg" alt="">
                   
                      </div>
                      <div class="tab-pane fade" id="pills-product-description" role="tabpanel" aria-labelledby="pills-product-description-tab"
                      tabindex="1">
					  <?php echo wpautop($full_description); ?>
                    
                      </div>
                      <div class="tab-pane fade" id="pills-shipping-poicy" role="tabpanel" aria-labelledby="pills-shipping-poicy-tab"
                      tabindex="2">
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nam necessitatibus nisi cumque quas deserunt aut. Perferendis voluptas adipisci, rem distinctio cumque nihil saepe tempore aut excepturi beatae ut. Non, deleniti.
                      </div>
                      </div>
            
            </div>
        </div>
    </section>


<?php endwhile; // end of the loop. ?>

<?php
/**
 * woocommerce_after_main_content hook.
 *
 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
 */
do_action('woocommerce_after_main_content');
?>

<?php
/**
 * woocommerce_sidebar hook.
 *
 * @hooked woocommerce_get_sidebar - 10
 */
// do_action( 'woocommerce_sidebar' );
?>

<?php
get_footer('shop');

/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */
