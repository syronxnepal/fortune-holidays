


    // var heroSwiper = new Swiper(".hero-slider", {
    //     //   effect: "coverflow",
    //     //   grabCursor: true,
    //     //   centeredSlides: true,
    //     //   slidesPerView: "auto",
    //       loop: true,
    //       effect: 'fade',
    //       fadeEffect: {
    //         crossFade: true,

    //       },
    //       speed:2000,

      
    //       autoplay: {
    //         delay: 2500,
    //         disableOnInteraction: false,
    //         },     
    //     //   coverflowEffect: {
    //     //     rotate: 50,
    //     //     stretch: 0,
    //     //     depth: 100,
    //     //     modifier: 1,
    //     //     slideShadows: true,
    //     //   },
    //       navigation: {
    //         nextEl: '.hero-swiper-button-next',
    //         prevEl: '.hero-swiper-button-prev',
    //       },
    //       pagination: {
    //         el: ".hero-swiper-pagination",
    //       },
    //     });
    const progressCircle = document.querySelector(".autoplay-progress svg");
    const progressContent = document.querySelector(".autoplay-progress span");

    
        var swiper = new Swiper(".hero-slider", {
          speed: 600,
          parallax: true,
          loop: true,
          autoplay: {
            delay: 2500,
            disableOnInteraction: false,
            },
          pagination: {
            el: ".swiper-pagination",
            clickable: true,
          },
          navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          },
          on: {
            autoplayTimeLeft(s, time, progress) {
              progressCircle.style.setProperty("--progress", 1 - progress);
              progressContent.textContent = `${Math.ceil(time / 1000)}s`;
            }
          }
    
        });
    