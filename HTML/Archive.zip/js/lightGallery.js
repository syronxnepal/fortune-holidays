
function waitForElement4(
    querySelector1,
    timeout = 0
  ) {
    const startTime = new Date().getTime();
    return new Promise((resolve, reject) => {
      const timer = setInterval(() => {
        const now = new Date().getTime();
        if (
          document.querySelector(querySelector1)
        ) {
          clearInterval(timer);
          resolve();
        } else if (timeout && now - startTime >= timeout) {
          clearInterval(timer);
          reject();
        }
      }, 100);
    });
  }

  waitForElement4("#room-gallery", 3000).then(function(){
    const lgContainer = document.getElementById('room-gallery');
const inlineGallery = lightGallery(lgContainer, {
    container: lgContainer,
    // plugins: [lgZoom, lgThumbnail],
    // dynamic: true,
    // Turn off hash plugin in case if you are using it
    // as we don't want to change the url on slide change
    hash: false,
    // Do not allow users to close the gallery
    closable: false,
    // Add maximize icon to enlarge the gallery
    scale: 1,
    showMaximizeIcon:true,
    zoom: true,
    infiniteZoom: true,
    actualSize: true,
    showZoomInOutIcons: false,
    enableZoomAfter: 300,
    actualSizeIcons: {
        zoomIn: 'lg-zoom-in',
        zoomOut: 'lg-zoom-out',
        viewActualSize: 'lg-actual-size',
    },
    zoomPluginStrings: {
        zoomIn: 'Zoom in',
        zoomOut: 'Zoom out',
        viewActualSize: 'View actual size',
    },

    // actualSizeIcons: true,
    // actualSize: true,

    // licenseKey: 'your_license_key',
    speed: 500,
    // ... other settings
});

  
setTimeout(() => {
    inlineGallery.openGallery();
  }, 200);
  })
  .catch(() => {
  console.log("return date and  type selector did not load in 3 seconds");
  });





// setTimeout(() => {
//     inlineGallery.openGallery();
//   }, 200);