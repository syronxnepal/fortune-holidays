var bookBox = document.querySelector(".ap-images-top");

window.addEventListener("scroll", () => {
  let options = {
    // root: document.querySelector("#comment-box"),
    rootMargin: "0px",
    threshold: 0.5,
  };

  let callback = (entries, observer) => {
    entries.forEach((entry) => {
      if (
        window.scrollY > 150 &&
        !entry.isIntersecting &&
        entry.boundingClientRect.y > 0
      ) {
        bookBox.classList.add("book-sticky");
      } else {
        bookBox.classList.remove("book-sticky");
      }
    });
  };
  let observer = new IntersectionObserver(callback, options);
  let target = document.querySelector("#apartment-map");
  observer.observe(target);
});
