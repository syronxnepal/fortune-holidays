

    var activitySwiper = new Swiper(".activity-slider", {
    //   effect: "coverflow",
    //   grabCursor: true,
    //   centeredSlides: true,
    //   slidesPerView: "auto",
      loop: true,
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
        },     
    //   coverflowEffect: {
    //     rotate: 50,
    //     stretch: 0,
    //     depth: 100,
    //     modifier: 1,
    //     slideShadows: true,
    //   },
      navigation: {
        nextEl: '.acivity-swiper-button-next',
        prevEl: '.activity-swiper-button-prev',
      },
      pagination: {
        el: ".activity-swiper-pagination",
      },
    });

  